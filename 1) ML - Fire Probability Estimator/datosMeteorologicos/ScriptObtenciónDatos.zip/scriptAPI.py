import http.client
import ssl
import json
import pandas as pd
import datetime
import requests
import csv
import time
from datetime import timedelta, date
import sys


# Esta función te dirá si el año es bisiesto o no, para administrar las peticiones a la API
def leapYear(year):
    if year % 4 == 0 and year % 100 != 0 or year % 400 == 0:
        return True
    else:
        return False


# Saca en formato fecha la inicial y la final
def writeDate(inputYear, inputMonth, leapYearBoolean):
    outputDay = 1
    if (inputMonth == 1) or (inputMonth == 3) or (inputMonth == 5) or (inputMonth == 7) or (inputMonth == 8) or (inputMonth == 10) or (inputMonth == 12):
        outputDay = 31
    elif (inputMonth == 4) or (inputMonth == 6) or (inputMonth == 9) or (inputMonth == 11):
        outputDay = 30
    elif inputMonth == 2 and (leapYearBoolean is True):
        outputDay = 29
    elif inputMonth == 2 and (leapYearBoolean is False):
        outputDay = 28

    start_date = date(inputYear, inputMonth, 1)
    end_date = date(inputYear, inputMonth, outputDay)

    dates = [start_date, end_date]

    return dates


# Escribe en el fichero, es el paso final.
def writeFile(list, year, idst):
    with open('datos' + idst + '_' + str(year) + '.csv', 'a') as myfile:
        wr = csv.writer(myfile, delimiter=':',
                        quotechar='"',
                        quoting=csv.QUOTE_ALL)
        for row in list:
            wr.writerow(row)
    myfile.close()


# Petición a la API
def GetData(fechaIni, fechaFin, idst, conn):
    headers = {
        'cache-control': "no-cache"
    }

    conn.request("GET",
                 f"/opendata/api/valores/climatologicos/diarios/datos/fechaini/{fechaIni}T00:00:00UTC/fechafin/{fechaFin}T23:59:59UTC/estacion/{idst}/?api_key=eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJwYWJsb3BzMTFAdXNhbC5lcyIsImp0aSI6ImMyMGY1MWQ1LTE2Y2ItNDQxYy05ZmExLTQ4MmE4NzBkMTM3YyIsImlzcyI6IkFFTUVUIiwiaWF0IjoxNTE5ODMwOTU4LCJ1c2VySWQiOiJjMjBmNTFkNS0xNmNiLTQ0MWMtOWZhMS00ODJhODcwZDEzN2MiLCJyb2xlIjoiIn0.r_PN4AJdmGkJ9wKwTReUqiyTNYkUM29m-icuiwBxmYQ",
                 headers=headers, )
    res = conn.getresponse()
    data = res.read().decode('utf-8', 'ignore')
    data = json.loads(data)

    conn.request("GET", data['datos'], headers=headers, )
    res = conn.getresponse()
    datos = res.read().decode('utf-8', 'ignore')
    datos = json.loads(datos)

    return datos


def requestAdmin(year, idst):
    month = 1
    leap = leapYear(year)

    while month <= 12:
        dates = writeDate(year, month, leap)
        h = GetData(dates[0], dates[1], idst, conn)
        lista = []
        for i in h:
            lista.append(list(i.values()))

        writeFile(lista, year, idst)
        month += 1
        time.sleep(4)


# Recoge los parámetros pasados por consola, que es el año y el id de la estación.
year = int(sys.argv[1])
id = sys.argv[2]

context = ssl.create_default_context()
context.check_hostname = False
context.verify_mode = ssl.CERT_NONE
conn = http.client.HTTPSConnection("opendata.aemet.es", context=context)

# Función principal.
requestAdmin(year, id)
