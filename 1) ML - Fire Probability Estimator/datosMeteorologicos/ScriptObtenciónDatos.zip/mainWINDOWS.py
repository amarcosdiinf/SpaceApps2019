# -*- coding: utf-8 -*-

from subprocess import call
import sys


def menu():
    print("\nIntroduce la estación de Madrid de la que quieres obtener los datos: ")
    print("1) Aranjuez - 3100B. \n")
    print("2) Buitrago de Lozoya - 3110C. \n")
    print("3) Colmenar Viejo - 3191E. \n")
    print("4) Getafe - 3200. \n")
    print("5) Aeropuerto - 3129. \n")
    print("6) Ciudad Universitaria - 3194U. \n")
    print("7) Cuatro Vientos - 3196. \n")
    print("8) Retiro - 3195. \n")
    print("9) Puerto Alto del León - 3266A. \n")
    print("10) Puerto de Navacerrada - 2462. \n")
    print("11) Robledo de Chavela - 3338. \n")
    print("12) Somosierra - 3111D. \n")
    print("13) Torrejón de Ardoz - 3175. \n")
    opt = int(input())
    return opt


if len(sys.argv) == 1:
    print("Introduce el año del que quieres sacar los datos: ")
    year = input()

    opt = -1
    while (opt <= 0) or (opt > 13):
        opt = menu()
        if opt == 1:
            id = '3100B'
        elif opt == 2:
            id = '3110C'
        elif opt == 3:
            id = '3191E'
        elif opt == 4:
            id = '3200'
        elif opt == 5:
            id = '3129'
        elif opt == 6:
            id = '3194U'
        elif opt == 7:
            id = '3196'
        elif opt == 8:
            id = '3195'
        elif opt == 9:
            id = '3266A'
        elif opt == 10:
            id = '2462'
        elif opt == 11:
            id = '3338'
        elif opt == 12:
            id = '3111D'
        elif opt == 13:
            id = '3175'
        else:
            print("Has introducido un valor incorrecto, prueba de nuevo. \n")
elif len(sys.argv) == 2:
    year = sys.argv[1]

    opt = -1
    while (opt <= 0) or (opt > 13):
        opt = menu()
        if opt == 1:
            id = '3100B'
        elif opt == 2:
            id = '3110C'
        elif opt == 3:
            id = '3191E'
        elif opt == 4:
            id = '3200'
        elif opt == 5:
            id = '3129'
        elif opt == 6:
            id = '3194U'
        elif opt == 7:
            id = '3196'
        elif opt == 8:
            id = '3195'
        elif opt == 9:
            id = '3266A'
        elif opt == 10:
            id = '2462'
        elif opt == 11:
            id = '3338'
        elif opt == 12:
            id = '3111D'
        elif opt == 13:
            id = '3175'
        else:
            print("Has introducido un valor incorrecto, prueba de nuevo. \n")
else:
    year = sys.argv[1]
    id = sys.argv[2]

arguments = ['python', 'scriptAPI.py', year, id]
call(arguments)
